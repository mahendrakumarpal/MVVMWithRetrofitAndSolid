package com.example.fitpeoapplication.constants

object AppConstants {
    const val BASE_URL = "https://jsonplaceholder.typicode.com/"
    const val PHOTO_URL = "photos"
}