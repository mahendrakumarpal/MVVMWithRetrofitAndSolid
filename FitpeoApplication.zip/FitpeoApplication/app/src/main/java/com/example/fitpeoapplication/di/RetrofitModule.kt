package com.example.fitpeoapplication.di

import com.example.fitpeoapplication.constants.AppConstants
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityRetainedComponent
import dagger.hilt.android.scopes.ActivityRetainedScoped
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit


@InstallIn(ActivityRetainedComponent::class)
@Module
object RetrofitModule {

    @ActivityRetainedScoped
    @Provides
    fun provideBaseRetrofit(): Retrofit =
        getRetrofitInstance(AppConstants.BASE_URL)
}

fun getRetrofitInstance(retrofitType: String): Retrofit {
    return Retrofit.Builder()
        .baseUrl(retrofitType)
        .addConverterFactory(GsonConverterFactory.create())
        .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
        .client(getOkHttpClient())
        .build()
}

fun getOkHttpClient(): OkHttpClient {
    val okHttpClient = OkHttpClient.Builder()
    val interceptor = HttpLoggingInterceptor()
    interceptor.apply {
        interceptor.level = HttpLoggingInterceptor.Level.BODY
    }
    okHttpClient.addInterceptor(interceptor)
    okHttpClient.connectTimeout(2, TimeUnit.MINUTES)
    okHttpClient.readTimeout(2, TimeUnit.MINUTES)
    okHttpClient.writeTimeout(2, TimeUnit.MINUTES)
    return okHttpClient.build()
}