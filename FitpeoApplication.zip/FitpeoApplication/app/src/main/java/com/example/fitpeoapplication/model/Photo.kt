package com.example.fitpeoapplication.model

data class Photo(
    var id: String = "",
    var albumId: String = "",
    var title: String = "",
    var url: String = "",
    var thumbnailUrl: String = "",
)