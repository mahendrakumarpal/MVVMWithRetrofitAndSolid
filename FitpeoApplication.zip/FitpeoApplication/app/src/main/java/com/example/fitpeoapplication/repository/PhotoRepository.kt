package com.example.fitpeoapplication.repository

import com.example.fitpeoapplication.model.Photo
import com.example.fitpeoapplication.services.PhotoApiService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

open class PhotoRepository @Inject constructor(
    private val photoApiService: PhotoApiService
) {
    open fun getPhotoFromApi(): Flow<MutableList<Photo>> = flow {
        emit(photoApiService.getPhotoList())
    }.flowOn(Dispatchers.IO)
}