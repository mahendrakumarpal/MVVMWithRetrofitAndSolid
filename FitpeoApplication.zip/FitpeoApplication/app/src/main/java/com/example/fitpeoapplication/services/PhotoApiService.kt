package com.example.fitpeoapplication.services

import com.example.fitpeoapplication.constants.AppConstants
import com.example.fitpeoapplication.model.Photo
import retrofit2.http.GET

interface PhotoApiService {

    @GET(AppConstants.PHOTO_URL)
    suspend fun getPhotoList() : MutableList<Photo>
}