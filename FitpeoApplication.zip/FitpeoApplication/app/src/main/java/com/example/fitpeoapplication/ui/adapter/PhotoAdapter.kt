package com.example.fitpeoapplication.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.fitpeoapplication.databinding.ItemPhotoBinding
import com.example.fitpeoapplication.model.Photo
import com.example.fitpeoapplication.util.DiffUtilCallback

class PhotoAdapter(private val itemClickListener: ItemClickListener) :
    RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder>() {
    private var baseModelList: MutableList<Photo> = mutableListOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        return PhotoViewHolder(
            ItemPhotoBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int = baseModelList.size

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        with(holder) {
            binding.movie = baseModelList[position]
            binding.itemClickListener = itemClickListener
        }
    }
    inner class PhotoViewHolder(val binding: ItemPhotoBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun getItemViewType(position: Int) = position

    interface ItemClickListener {
        fun onItemClicked(movie: Photo)
    }
    fun setData(newList: MutableList<Photo>) {
        val diffCallback = DiffUtilCallback(baseModelList, newList)
        val diffResult = DiffUtil.calculateDiff(diffCallback)
        baseModelList.clear()
        baseModelList.addAll(newList)
        diffResult.dispatchUpdatesTo(this)
    }
}