package com.example.fitpeoapplication.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.viewbinding.ViewBinding
import com.example.fitpeoapplication.viewmodels.PhotoViewModel


abstract class BaseFragmentBinding<VB: ViewBinding> : Fragment() {
    private var _binding: VB? = null
    lateinit var viewBinding: VB

    val photoViewModel: PhotoViewModel by activityViewModels()

    abstract fun getBinding(inflater: LayoutInflater, container: ViewGroup?): VB?

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = getBinding(inflater, container)
        _binding?.let {
            viewBinding = it
        }
        return viewBinding.root
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}