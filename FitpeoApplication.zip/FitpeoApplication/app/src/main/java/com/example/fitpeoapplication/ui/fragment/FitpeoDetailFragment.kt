package com.example.fitpeoapplication.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.fitpeoapplication.databinding.FragmentFitpeoDetailBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FitpeoDetailFragment : BaseFragmentBinding<FragmentFitpeoDetailBinding>() {

    override fun getBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ) = FragmentFitpeoDetailBinding.inflate(inflater, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        photoViewModel.selectedPhotoMutableLiveData.observe(viewLifecycleOwner) { photo ->
            viewBinding.photo = photo
        }
    }
}