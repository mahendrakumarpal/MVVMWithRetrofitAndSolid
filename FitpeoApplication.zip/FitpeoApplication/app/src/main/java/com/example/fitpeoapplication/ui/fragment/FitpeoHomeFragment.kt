package com.example.fitpeoapplication.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.fitpeoapplication.R
import com.example.fitpeoapplication.databinding.FragmentFitpeoHomeBinding
import com.example.fitpeoapplication.model.Photo
import com.example.fitpeoapplication.ui.adapter.PhotoAdapter
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FitpeoHomeFragment : BaseFragmentBinding<FragmentFitpeoHomeBinding>(),
    PhotoAdapter.ItemClickListener {

    private lateinit var photoAdapter: PhotoAdapter

    override fun getBinding(
        inflater: LayoutInflater,
        container: ViewGroup?
    ) = FragmentFitpeoHomeBinding.inflate(inflater, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        photoAdapter = PhotoAdapter(this)
        viewBinding.rvList.adapter = photoAdapter
        photoViewModel.getPhotoFromApi().observe(viewLifecycleOwner) { photoList ->
            photoAdapter.setData(photoList)
        }
    }

    override fun onItemClicked(photo: Photo) {
        photoViewModel.selectedPhotoMutableLiveData.value = photo
        findNavController().navigate(R.id.action_fitpeohome_to_fitpeodetail)
    }
}