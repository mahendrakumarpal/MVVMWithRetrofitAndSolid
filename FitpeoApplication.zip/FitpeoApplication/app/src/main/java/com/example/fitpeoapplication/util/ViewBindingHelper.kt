package com.example.fitpeoapplication.util

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.squareup.picasso.Picasso


object ViewBindingHelper {

    @JvmStatic
    @BindingAdapter("app:loadThumbnail")
    fun ImageView.loadThumbnailUrl(thumbnail: String?) {
        thumbnail?.let { url ->
            Picasso.get().load(url).into(this)
        }
    }
}