package com.example.fitpeoapplication.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.example.fitpeoapplication.model.Photo
import com.example.fitpeoapplication.repository.PhotoRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class PhotoViewModel @Inject constructor(
    private val photoRepository: PhotoRepository
) : ViewModel() {

    var selectedPhotoMutableLiveData = MutableLiveData<Photo>()

    fun getPhotoFromApi() = photoRepository.getPhotoFromApi().asLiveData()
}