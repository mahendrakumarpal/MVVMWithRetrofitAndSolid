package com.example.fitpeoapplication.repository

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Rule
import org.mockito.Mockito


@ExperimentalCoroutinesApi
abstract class AbstractRepositoryTest {
    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    protected inline fun <reified T> mock(): T = Mockito.mock(T::class.java)
}