package com.example.fitpeoapplication.repository

import com.example.fitpeoapplication.services.PhotoApiService
import com.example.fitpeoapplication.util.JunitUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.mockito.Mockito

@ExperimentalCoroutinesApi
class PhotoRepositoryTest : AbstractRepositoryTest() {
    private lateinit var photoRepository: PhotoRepository
    private val photoApiService: PhotoApiService = mock()

    @Before
    fun initPhotoRepository(){
        photoRepository = PhotoRepository(photoApiService)
    }

    @Test
    fun `getPhotoFromApi() returns true when photo data stream present`() = runBlocking {
        val photoList = JunitUtils.getPhotoDummyList()

        Mockito.`when`(photoApiService.getPhotoList()).thenReturn(photoList)

        val photo = photoRepository.getPhotoFromApi().first()
        Assert.assertTrue(photo.isNotEmpty())
        Assert.assertEquals("1", photo[1].id)
    }
}