package com.example.fitpeoapplication.util

import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.example.fitpeoapplication.model.Photo
import java.util.*
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

object JunitUtils {

    fun <T> LiveData<T>.getOrAwaitValue(
        time: Long = 2,
        timeUnit: TimeUnit = TimeUnit.SECONDS,
        afterObserve: () -> Unit = {}
    ): T {
        var data: T? = null
        val latch = CountDownLatch(1)
        val observer = object : Observer<T> {
            override fun onChanged(value: T) {
                data = value
                latch.countDown()
                removeObserver(this)
            }
        }
        observeForever(observer)
        try {
            afterObserve.invoke()
            if (!latch.await(time, timeUnit)) {
                throw TimeoutException("LiveData value was never set.")
            }
        } finally {
            removeObserver(observer)
        }
        @Suppress("UNCHECKED_CAST")
        return data as T
    }

    fun getPhotoDummyList(): MutableList<Photo> {
        val photoList = mutableListOf<Photo>()
        photoList.apply {
            add(
                Photo(
                    "1",
                    "1",
                    "accusamus beatae ad facilis cum similique qui sunt",
                    "https://via.placeholder.com/600/92c952",
                    "https://via.placeholder.com/150/92c952"
                )
            )
            add(
                Photo(
                    "1",
                    "2",
                    "reprehenderit est deserunt velit ipsam",
                    "https://via.placeholder.com/600/92c952",
                    "https://via.placeholder.com/150/92c952"
                )
            )
            add(
                Photo(
                    "1",
                    "3",
                    "officia porro iure quia iusto qui ipsa ut modi",
                    "https://via.placeholder.com/600/92c952",
                    "https://via.placeholder.com/150/92c952"
                )
            )
            add(
                Photo(
                    "1",
                    "4",
                    "culpa odio esse rerum omnis laboriosam voluptate repudiandae",
                    "https://via.placeholder.com/600/92c952",
                    "https://via.placeholder.com/150/92c952"
                )
            )
        }
        return photoList
    }

    fun getPhotoDummyData(): Photo {
        return Photo(
            "1",
            "1",
            "accusamus beatae ad facilis cum similique qui sunt",
            "https://via.placeholder.com/600/92c952",
            "https://via.placeholder.com/150/92c952"
        )
    }
}


