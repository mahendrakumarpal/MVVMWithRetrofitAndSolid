package com.example.fitpeoapplication.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.Observer
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Rule
import org.mockito.Mockito


@ExperimentalCoroutinesApi
abstract class AbstractViewModelTest {

    @get:Rule
    var instantExecutorRule = InstantTaskExecutorRule()

    inline fun <reified T> mock(): T = Mockito.mock(T::class.java)
    protected var observer = mock<Observer<in Any>>()
}