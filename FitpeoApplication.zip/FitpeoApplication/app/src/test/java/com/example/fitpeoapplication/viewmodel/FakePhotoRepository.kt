package com.example.fitpeoapplication.viewmodel

import com.example.fitpeoapplication.model.Photo
import com.example.fitpeoapplication.repository.PhotoRepository
import com.example.fitpeoapplication.services.PhotoApiService
import com.example.fitpeoapplication.util.JunitUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

open class FakePhotoRepository(photoApiService: PhotoApiService): PhotoRepository(photoApiService) {
    private val photoList = JunitUtils.getPhotoDummyList()
    override fun getPhotoFromApi(): Flow<MutableList<Photo>> {
        val flowOfPhotoList = flow {
            emit(photoList)
        }
        return flowOfPhotoList
    }
}