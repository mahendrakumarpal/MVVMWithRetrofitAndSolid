package com.example.fitpeoapplication.viewmodel

import com.example.fitpeoapplication.util.JunitUtils
import com.example.fitpeoapplication.util.JunitUtils.getOrAwaitValue
import com.example.fitpeoapplication.util.TestDispatcherRule
import com.example.fitpeoapplication.viewmodels.PhotoViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.runBlocking
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito

@ExperimentalCoroutinesApi
class PhotoViewModelTest : AbstractViewModelTest() {

    private lateinit var photoViewModel: PhotoViewModel
    private var photoRepository: FakePhotoRepository = mock()
    @get:Rule
    val testDispatcher = TestDispatcherRule()
    @Before
    fun setUp() {
        photoViewModel = PhotoViewModel(photoRepository)
    }

    @Test
    fun `photoLiveData success case`() = runBlocking {
        val photoList = JunitUtils.getPhotoDummyList()
        val flowOfPhotoList = flow {
            emit(photoList)
        }

        Mockito.`when`(photoRepository.getPhotoFromApi()).thenReturn(flowOfPhotoList)
        val list = photoViewModel.getPhotoFromApi().getOrAwaitValue()
        Assert.assertEquals("1", list[1].id)

    }

    @Test
    fun `selectedPhotoMutableLiveData success case`() = runBlocking {
        val photo = JunitUtils.getPhotoDummyData()
        photoViewModel.selectedPhotoMutableLiveData.value = photo
        val selectedPhoto = photoViewModel.selectedPhotoMutableLiveData.getOrAwaitValue()
        Assert.assertEquals("1",selectedPhoto.id)
    }
}